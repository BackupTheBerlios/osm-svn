/*
 * @(#)PropertiesService.java
 *
 * Copyright 2002 OSM SARL. All Rights Reserved.
 * 
 * This software is the proprietary information of OSM SARL.  
 * Use is subject to license terms.
 * 
 * @author  Stephen McConnell
 * @version 1.0 16/03/2002
 */

package net.osm.properties;

import org.omg.CosPropertyService.PropertySetDef;
import org.apache.avalon.framework.component.Component;
import org.omg.CosPersistentState.StorageObject;
import org.omg.CosPersistentState.NotFound;

/**
 * The <code>PropertiesService</code> is curently an empty service 
 * interface declaration until we know what we need.
 *
 * @author <a href="mailto:mcconnell@osm.net">Stephen McConnell</a>
 */
public interface PropertiesService extends Component
{

    public static final String PROPERTY_SERVICE_KEY = "properties.key";
 
   /**
    * Creation of a new <code>PropertySetDef</code> object reference.
    * @param key unique identifier
    * @exception PropertyException
    */
    public PropertySetDef createPropertySetDef( byte[] key ) 
    throws PropertyException;

   /**
    * Locate a new <code>PropertySetDef</code> based on a supplied container.
    * @param key unique identifier
    * @exception NotFound if the property set does not exist
    */
    public PropertySetDef locatePropertySetDef( byte[] key ) 
    throws NotFound;
}
