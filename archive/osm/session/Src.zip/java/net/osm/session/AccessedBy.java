// Sun Dec 17 16:53:23 CET 2000

package net.osm.session;

import java.io.Serializable;

import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.StreamableValue;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.ValueFactory;

import org.omg.Session.User;
import org.omg.Session.AbstractResource;

public class AccessedBy extends org.omg.Session.AccessedBy
implements ValueFactory
{

    //========================================================================
    // constructors
    //========================================================================
    
   /**
    * Default constructor for stream internalization.
    */
    public AccessedBy () 
    {
    }

   /**
    * Creation of a new AccessedBy link based on a supplied User.
    */
    public AccessedBy( User resource ) 
    {
	  super.resource_state = resource;
    }

    //========================================================================
    // Link
    //========================================================================

   /**
    * The resource operation returns the <code>User</code> that 
    * is authorized to access the Workspace holding this link.
    * @return  AbstractResource representing the user holding the right of access.
    */
    public AbstractResource resource()
    {
	  return super.resource_state;
    }

    //========================================================================
    // ValueFactory
    //========================================================================

   /**
    * AccessedBy factory.
    */
    public Serializable read_value(org.omg.CORBA_2_3.portable.InputStream is) {
        return is.read_value( new AccessedBy() );
    }
}
