// Sun Dec 17 16:53:23 CET 2000

package net.osm.session.task;

import java.io.Serializable;

import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.StreamableValue;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.ValueFactory;

import org.omg.Session.User;
import org.omg.Session.AbstractResource;

public class DefaultExecutedBy extends net.osm.session.task.ExecutedBy
implements ValueFactory
{

    //========================================================================
    // constructors
    //========================================================================
    
   /**
    * Default constructor for stream internalization.
    */
    public DefaultExecutedBy () 
    {
    }

   /**
    * Creation of a new ExecutedBy link based on a supplied AbstractResource.
    */
    public DefaultExecutedBy( AbstractResource resource ) 
    {
	  super.resource_state = resource;
    }

    //========================================================================
    // Link
    //========================================================================

   /**
    * The resource operation returns the <code>AbstractResource</code> that 
    * is acting as the processor to the <code>Task</code> holding this link.
    * @return  AbstractResource acting as the processor
    */
    public AbstractResource resource()
    {
	  return super.resource_state;
    }

    //========================================================================
    // ValueFactory
    //========================================================================

   /**
    * AccessedBy factory.
    */
    public Serializable read_value(org.omg.CORBA_2_3.portable.InputStream is) {
        return is.read_value( new DefaultExecutedBy() );
    }
}
