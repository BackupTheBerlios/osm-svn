/*
 * Copyright 2000 OSM SARL. All Rights Reserved.
 * 
 * This software is the proprietary information of OSM SARL.  
 * Use is subject to license terms.
 * 
 * @author  Stephen McConnell
 * @version 1.0 26/03/2001
 */

package net.osm.session.finder;

import java.io.File;
import java.util.Hashtable;
import java.security.Principal;
import java.security.cert.CertPath;
import javax.security.auth.x500.X500Principal;

import org.apache.avalon.framework.logger.Logger;
import org.apache.avalon.framework.logger.LogEnabled;
import org.apache.avalon.framework.logger.AbstractLogEnabled;
import org.apache.avalon.framework.context.Context;
import org.apache.avalon.framework.context.Contextualizable;
import org.apache.avalon.framework.context.ContextException;
import org.apache.avalon.framework.activity.Disposable;
import org.apache.avalon.framework.activity.Initializable;
import org.apache.avalon.framework.activity.Startable;
import org.apache.avalon.framework.logger.LogEnabled;
import org.apache.avalon.framework.configuration.Configurable;
import org.apache.avalon.framework.configuration.Configuration;
import org.apache.avalon.framework.configuration.ConfigurationException;
import org.apache.avalon.framework.service.Serviceable;
import org.apache.avalon.framework.service.ServiceManager;
import org.apache.avalon.framework.service.ServiceException;
import org.apache.avalon.phoenix.BlockContext;
import org.apache.avalon.phoenix.Block;

import org.apache.orb.ORBContext;
import org.apache.pss.ConnectorContext;
import org.apache.pss.SessionContext;
import org.apache.pss.Connector;
import org.apache.pss.Session;
import org.apache.pss.ORB;

import org.omg.CORBA.Any;
import org.omg.CORBA.LocalObject;
import org.omg.CORBA.Policy;
import org.omg.CosPersistentState.NotFound;
import org.omg.CosPersistentState.StorageObject;
import org.omg.PortableServer.ServantLocator;
import org.omg.PortableServer.Servant;
import org.omg.PortableServer.POA;
import org.omg.PortableServer.ServantLocatorPackage.CookieHolder ;
import org.omg.PortableServer.ForwardRequest;
import org.omg.PortableServer.POAHelper;
import org.omg.PortableServer.IdAssignmentPolicyValue;
import org.omg.PortableServer.RequestProcessingPolicyValue;
import org.omg.PortableServer.ImplicitActivationPolicyValue;
import org.omg.PortableServer.LifespanPolicyValue;
import org.omg.PortableServer.IdUniquenessPolicyValue;
import org.omg.PortableServer.ServantRetentionPolicyValue;
import org.omg.CosNaming.NameComponent;
import org.omg.CosLifeCycle.NoFactory;
import org.omg.Session.AbstractResource;
//import org.omg.Session.User;

import net.osm.realm.StandardPrincipal;
import net.osm.realm.PrincipalManager;
import net.osm.realm.PrincipalManagerHelper;
import net.osm.session.user.UserService;
import net.osm.session.SessionException;
import net.osm.session.SessionRuntimeException;
import net.osm.session.workspace.WorkspaceService;
import net.osm.session.task.TaskService;
import net.osm.session.desktop.DesktopService;
import net.osm.session.user.User;


/**
 * The <code>FinderDelegate</code> block provides bootstrap services 
 * enabling the establishment of initial objects into the environment.
 *
 * @author <a href="mailto:mcconnell@osm.net">Stephen McConnell</a>
 */

public class FinderDelegate extends AbstractLogEnabled 
implements Block, Contextualizable, Serviceable, Configurable, Initializable, Disposable, FinderOperations
{
    //==================================================
    // state
    //==================================================

    private Context m_context;
    private Configuration m_config;
    private ServiceManager m_manager;

    private PrincipalManager m_principal_manager;
    private UserService m_user_service;
    private DesktopService m_desktop_service;
    private WorkspaceService m_workspace_service;
    private TaskService m_task_service;
    private ORB m_orb;

    //=================================================================
    // Contextualizable
    //=================================================================

   /**
    * Set the block context.
    * @param context the block context
    * @exception ContextException if the block cannot be narrowed to BlockContext
    */
    public void contextualize( Context context ) throws ContextException
    {
        if( getLogger().isDebugEnabled() ) getLogger().debug( "contextualize" );
        m_context = context;
    }

    
    //=======================================================================
    // Configurable
    //=======================================================================
    
    public void configure( final Configuration config )
    throws ConfigurationException
    {
	  if( getLogger().isDebugEnabled() ) getLogger().debug( "configuration" );
        m_config = config;
    }

    //=======================================================================
    // Serviceable
    //=======================================================================

    /**
     * Pass the <code>ServiceManager</code> to the <code>Serviceable</code>.
     * The <code>Serviceable</code> implementation uses the supplied
     * <code>ServiceManager</code> to acquire the components it needs for
     * execution.
     * @param manager the <code>ServiceManager</code> for this delegate
     * @exception ServiceException
     */
    public void service( ServiceManager manager )
    throws ServiceException
    {
	  if( getLogger().isDebugEnabled() ) getLogger().debug( "service" );
        m_manager = manager;
    }

    //=======================================================================
    // Initializable
    //=======================================================================
    
    public void initialize()
    throws Exception
    {
        if( getLogger().isDebugEnabled() ) getLogger().debug( "initialization" );
        m_orb = (ORB) m_manager.lookup( ORBContext.ORB_KEY );
        m_user_service = (UserService) m_manager.lookup( UserService.USER_SERVICE_KEY );
        m_desktop_service = (DesktopService) m_manager.lookup( DesktopService.DESKTOP_SERVICE_KEY );
        m_workspace_service = (WorkspaceService) m_manager.lookup( WorkspaceService.WORKSPACE_SERVICE_KEY );
        m_task_service = (TaskService) m_manager.lookup( TaskService.TASK_SERVICE_KEY );
    }

    //=======================================================================
    // Disposable
    //=======================================================================
        
    public void dispose()
    {
        if( getLogger().isDebugEnabled() ) getLogger().debug( "disposal");
    }

    //=======================================================================
    // Finder
    //=======================================================================

   /**
    * Returns a user object reference representing the user identifier by 
    * the security current principal.
    *
    * @param policy a boolean value that if true means that the factory
    *   should create a new user reference if no existing user reference 
    *   can be found for the pricipal.
    * @exception UnknownPrincipal may be thrown if the policy is false and the 
    *   current principal does not map to an existing user
    */
    public User resolve_user( boolean policy ) throws UnknownPrincipal
    {

        // resolve or create user

	  try
	  {
		
		User user = m_user_service.locateUser();
		if( getLogger().isDebugEnabled() ) getLogger().debug("located existing user");
		return user;
        }
	  catch( NotFound nf )
	  {
            if( !policy ) throw new UnknownPrincipal( );
		try
		{
		    User user = m_user_service.createUser( );
		    if( getLogger().isInfoEnabled() ) getLogger().info("created new user");
		    return user;
		}
		catch( Throwable e )
	      {
	  	    String error = "Unexpected exception while creating user reference."; 
		    throw new SessionRuntimeException( error, e );
		}
        }
    }


   /**
    * Locate a resource by name.
    * @param name the lookup name for the resource
    * @return AbstractResource
    * @exception UnknownName if the name is unknown
    */
    public AbstractResource lookup( String name ) throws UnknownName
    {
        try
        {
            return m_workspace_service.createWorkspace( name );
        }
        catch( Throwable e )
        {
            throw new SessionRuntimeException( "test exception", e );
        }
        //throw new UnknownName( name );
    }

   /**
    * The find_factories operation is passed a key used to identify the desired factory.
    * The key is a name, as defined by the naming service. More than one factory may
    * match the key. As such, the factory finder returns a sequence of factories. If there are
    * no matches, the NoFactory exception is raised.<p>
    * The scope of the key is the factory finder. The factory finder assigns no semantics to
    * the key. It simply matches keys. It makes no guarantees about the interface or
    * implementation of the returned factories or objects they create.
    */
    public org.omg.CORBA.Object[] find_factories( NameComponent[] factory_key )
    throws NoFactory
    {
        throw new NoFactory();
    }

   /**
    * Returns a client principal invoking the operation.
    * @return StandardPrincipal the client principal
    */
    private StandardPrincipal getPrincipal() throws Exception
    {
        if( m_principal_manager == null ) m_principal_manager = PrincipalManagerHelper.narrow( 
			m_orb.resolve_initial_references( "PrincipalManager" ) );
	  return m_principal_manager.getPrincipal();
    }

}
