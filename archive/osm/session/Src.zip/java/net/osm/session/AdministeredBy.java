

package net.osm.session;

import java.io.Serializable;

import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.StreamableValue;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.ValueFactory;

import org.omg.Session.User;
import org.omg.Session.AbstractResource;

public class AdministeredBy extends org.omg.Session.AdministeredBy
implements ValueFactory
{
    
    //==========================================================
    // constructors
    //==========================================================
    
   /**
    * Default constructor for stream internalization.
    */
    public AdministeredBy() 
    {
    }

   /**
    * Creation of a new AdministeredBy link based on a supplied User.
    */
    public AdministeredBy( User resource ) 
    {
	  super.resource_state = resource;
    }

    //========================================================================
    // Link
    //========================================================================

   /**
    * The resource operation returns the <code>User</code> that 
    * administers the <code>Workspace</code> holding this link.
    * @return  AbstractResource representing the user holding the right of access.
    */
    public AbstractResource resource()
    {
	  return super.resource_state;
    }

    //==========================================================
    // ValueFactory
    //==========================================================
    
   /**
    * AdministeredBy factory.
    */
    public Serializable read_value(org.omg.CORBA_2_3.portable.InputStream is) 
    {
        return is.read_value( new AdministeredBy() );
    }

}
