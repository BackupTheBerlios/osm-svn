/*
 */
package net.osm.session;

import org.apache.orb.SingletonService;
import net.osm.session.finder.Finder;

/**
 * Interface supporting AbstractResource management actions.
 *
 * @author Stephen McConnell <mcconnell@osm.net>
 */

public interface SessionService extends SingletonService
{

    public static final String SESSION_SERVICE_KEY = "SESSION_SERVICE_KEY";


   /**
    * Returns an object refererence to the finder.
    * @return Finder the finder object reference.
    */
    public Finder getFinder();


}



