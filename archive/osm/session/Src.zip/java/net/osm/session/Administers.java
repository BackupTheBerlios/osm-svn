// Sun Dec 17 16:53:23 CET 2000

package net.osm.session;

import java.io.Serializable;

import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.StreamableValue;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.ValueFactory;
import org.omg.Session.AbstractResource;
import org.omg.Session.Workspace;


public class Administers extends org.omg.Session.Administers
implements ValueFactory
{
 
    //==========================================================
    // constructors
    //==========================================================
   
   /**
    * Default constructor for stream internalization.
    */
    public Administers() 
    {
    }

   /**
    * Creation of a new Administers link based on a supplied Workspace.
    */
    public Administers( Workspace resource ) 
    {
	  super.resource_state = resource;
    }

    //========================================================================
    // Link
    //========================================================================

   /**
    * The resource operation returns the <code>AbstractResource</code> that 
    * is adminstered by the <code>User</code> holding this link.
    * @return  AbstractResource representing the user holding the right of adminstration.
    */
    public AbstractResource resource()
    {
	  return super.resource_state;
    }

    //==========================================================
    // ValueFactory
    //==========================================================
        
   /**
    * Administers factory.
    */
    public Serializable read_value(org.omg.CORBA_2_3.portable.InputStream is) {
        return is.read_value( new Administers() );
    }

}
