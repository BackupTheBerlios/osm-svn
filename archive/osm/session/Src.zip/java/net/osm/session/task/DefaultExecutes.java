
package net.osm.session.task;

import java.io.Serializable;

import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.StreamableValue;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.ValueFactory;

import org.omg.Session.Access;
import org.omg.Session.AccessesHelper;
import org.omg.Session.AbstractResource;
import org.omg.Session.Workspace;

public class DefaultExecutes extends net.osm.session.task.Executes
implements ValueFactory
{

    //==========================================================
    // constructors
    //==========================================================
   
   /**
    * Default constructor for stream internalization.
    */
    public DefaultExecutes() 
    {
    }

   /**
    * Creation of a new Executes link based on a supplied Task.
    */
    public DefaultExecutes( Task task ) {
	  super.resource_state = task;
    }

    //==========================================================
    // Executes
    //==========================================================

   /**
    * The resource operation returns the <code>Task</code> that is
    * executed by the <code>AbstractResource</code> holding this link.
    * @return AbstractResource a <code>Task</code> the is processed 
    * by the <code>AbstractResource</code> holding this link.
    */
    public AbstractResource resource()
    {
	  return this.resource_state;
    }

   /**
    * Accesses factory.
    */
    public Serializable read_value(org.omg.CORBA_2_3.portable.InputStream is) {
        return is.read_value( new DefaultExecutes() );
    }

}
