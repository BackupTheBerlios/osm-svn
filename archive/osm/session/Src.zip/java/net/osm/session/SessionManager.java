/*
 * Copyright 2000 OSM SARL. All Rights Reserved.
 * 
 * This software is the proprietary information of OSM SARL.  
 * Use is subject to license terms.
 * 
 * @author  Stephen McConnell
 * @version 1.0 26/03/2001
 */

package net.osm.session;

import java.util.Random;

import org.apache.avalon.framework.logger.Logger;
import org.apache.avalon.framework.logger.LogEnabled;
import org.apache.avalon.framework.logger.AbstractLogEnabled;
import org.apache.avalon.framework.context.Context;
import org.apache.avalon.framework.context.Contextualizable;
import org.apache.avalon.framework.context.ContextException;
import org.apache.avalon.framework.component.Component;
import org.apache.avalon.framework.component.ComponentManager;
import org.apache.avalon.framework.activity.Disposable;
import org.apache.avalon.framework.activity.Executable;
import org.apache.avalon.framework.activity.Initializable;
import org.apache.avalon.framework.activity.Startable;
import org.apache.avalon.framework.logger.LogEnabled;
import org.apache.avalon.framework.configuration.Configurable;
import org.apache.avalon.framework.configuration.Configuration;
import org.apache.avalon.framework.configuration.ConfigurationException;
import org.apache.avalon.framework.service.DefaultServiceManager;
import org.apache.avalon.framework.service.ServiceManager;
import org.apache.avalon.framework.service.ServiceException;
import org.apache.avalon.framework.service.Serviceable;
import org.apache.avalon.phoenix.BlockContext;
import org.apache.avalon.phoenix.Block;

import org.apache.pss.ORB;
import org.apache.pss.Connector;
import org.apache.pss.ConnectorContext;
import org.apache.orb.ORBContext;
import org.apache.pss.DefaultSingletonManager;
import org.apache.pss.DefaultSessionContext;

import org.omg.CosTime.TimeService;
import org.omg.PortableServer.Servant;

import net.osm.domain.DomainService;
import net.osm.sps.StructuredPushSupplierService;
import net.osm.session.workspace.WorkspaceServantManager;
import net.osm.session.user.UserServantManager;
import net.osm.session.task.TaskServantManager;
import net.osm.session.desktop.DesktopServantManager;
import net.osm.session.workspace.WorkspaceService;
import net.osm.session.user.UserService;
import net.osm.session.task.TaskService;
import net.osm.session.desktop.DesktopService;
import net.osm.session.finder.FinderDelegate;
import net.osm.session.finder.FinderPOATie;
import net.osm.session.finder.Finder;
import net.osm.session.finder.FinderHelper;
import net.osm.session.SessionSingleton;
import net.osm.realm.RealmSingleton;

/**
 * The <code>SessionManager</code> encapsulates a family of components that 
 * provide support for the establishment and management of <code>User</code>s, 
 * <code>Task</code>s, <code>Workspace</code>s, <code>Messages</code>s that 
 * constitute a distributed people-places-and-things framework.
 *
 * @author <a href="mailto:mcconnell@osm.net">Stephen McConnell</a>
 */
public class SessionManager extends DefaultSingletonManager
implements Contextualizable, Configurable, Serviceable, Initializable, Startable, Disposable
{
    //=======================================================================
    // state
    //=======================================================================

    private Context m_context;
    private Configuration m_config;
    private ServiceManager m_manager;
    private boolean m_initialized = false;
    private boolean m_started = false;
    private boolean m_disposed = false;

    private ORB m_orb;
    private ConnectorContext m_connector_context;
    private TimeService m_clock;
    private DomainService m_domain_service;
    private StructuredPushSupplierService m_sps_service;

    private DesktopServantManager m_desktop = new DesktopServantManager();
    private WorkspaceServantManager m_workspace = new WorkspaceServantManager();
    private TaskServantManager m_task = new TaskServantManager();
    private UserServantManager m_user = new UserServantManager();

    private Finder m_finder;

    //=======================================================================
    // Contextualizable
    //=======================================================================

   /**
    * Set the component context.
    * @param context the component context
    */
    public void contextualize( Context context ) 
    throws ContextException
    {
        super.contextualize( context );
        m_context = context;
    }

    //=======================================================================
    // Configurable
    //=======================================================================

   /**
    * Used by a container to supply the static component configuration.
    * @param config the static configuration
    */    
    public void configure( final Configuration config )
    throws ConfigurationException
    {
        super.configure( config );
        m_config = config;
    }

    //=======================================================================
    // Serviceable
    //=======================================================================

    /**
     * Pass the <code>ServiceManager</code> to the <code>Serviceable</code>.
     * The <code>Serviceable</code> implementation uses the supplied
     * <code>ServiceManager</code> to acquire the components it needs for
     * execution.
     * @param manager the <code>ServiceManager</code> for this delegate
     * @exception ServiceException
     */
    public void service( ServiceManager manager )
    throws ServiceException
    {
        super.service( manager );
        m_manager = manager;
    }

    //=======================================================================
    // Initializable
    //=======================================================================
    
   /**
    * Initialization of the manager under which workspace, desktop, 
    * user and task managers are established.
    * @exception Exception if an error occurs during initalization
    */
    public void initialize()
    throws Exception
    {

        super.initialize();

	  m_orb = (ORB) m_manager.lookup( ORBContext.ORB_KEY );
        Connector connector = (Connector) m_orb.getConnector();
        Configuration pss = m_config.getChild("pss");
        connector.register( pss.getChild("persistence") );
        DefaultSessionContext context = new DefaultSessionContext(
          m_orb, connector, getSession(), m_context );

        RealmSingleton.init( m_orb );
        SessionSingleton.init( m_orb );

        //
        // logging phase
        //

        m_workspace.enableLogging( getLogger().getChildLogger( "workspace" ) );
        m_desktop.enableLogging( getLogger().getChildLogger( "desktop" ) );
        m_task.enableLogging( getLogger().getChildLogger( "task" ) );
        m_user.enableLogging( getLogger().getChildLogger( "user" ) );

        //
        // contextualization phase
        //

	  try
	  {
            m_workspace.contextualize( context );
            m_desktop.contextualize( context );
            m_task.contextualize( context );
            m_user.contextualize( context );
	  }
	  catch( Throwable e )
	  {
	      String error = "Unexpected establishment error during contextualization phase.";
		throw new SessionException( error, e );
	  }

        //
        // configuration phase
        //

	  try
	  {
            m_workspace.configure( m_config.getChild( "workspace" ) );
            m_desktop.configure( m_config.getChild( "desktop" ) );
            m_task.configure( m_config.getChild( "task" ) );
            m_user.configure( m_config.getChild( "user" ) );
	  }
	  catch( Throwable e )
	  {
	      String error = "Unexpected establishment error during configuration phase.";
		throw new SessionException( error, e );
	  }

        //
        // composition phase
        //

	  try
	  {
            DefaultServiceManager general_manager = new DefaultServiceManager( m_manager );
            general_manager.put( UserService.USER_SERVICE_KEY, m_user );
            m_workspace.service( general_manager );
            m_desktop.service( general_manager );
            m_task.service( general_manager );

            DefaultServiceManager user_manager = new DefaultServiceManager( m_manager );
            user_manager.put( DesktopService.DESKTOP_SERVICE_KEY, m_desktop );
            user_manager.put( WorkspaceService.WORKSPACE_SERVICE_KEY, m_workspace );
            user_manager.put( TaskService.TASK_SERVICE_KEY, m_task );
            m_user.service( user_manager );
	  }
	  catch( Throwable e )
	  {
	      String error = "Unexpected establishment error during composition phase.";
		throw new SessionException( error, e );
	  }

        //
        // initialization phase
        // 

	  try
	  {
            m_workspace.initialize();
            m_desktop.initialize();
            m_task.initialize();
            m_user.initialize();
	  }
	  catch( Throwable e )
	  {
	      String error = "Unexpected establishment error during initialization phase.";
		throw new SessionException( error, e );
	  }

        m_finder = FinderHelper.narrow( super.getService() );
        m_initialized = true;
    }

    //=======================================================================
    // Startable
    //=======================================================================

   /**
    * Starts the workspace, desktop, task and user managers.
    * @exception Exception if startup error is encountered.
    */
    public void start() throws Exception
    {
        super.start();

        try
        {
            m_workspace.start();
            m_desktop.start();
            m_task.start();
            m_user.start();
	  }
	  catch( Throwable e )
	  {
	      String error = "Unexpected establishment error during startup phase.";
		throw new SessionException( error, e );
	  }

        m_started = true;
    }

   /**
    * Stops the manager and all subsidiary managers.
    * @exception Exception if an error occurs
    */
    public void stop() throws Exception
    {
        if( !m_started ) throw new SessionException( 
	        "SessionManager has not been started." );

        try
        {
            m_workspace.stop();
            m_desktop.stop();
            m_task.stop();
            m_user.stop();
	  }
	  catch( Throwable e )
	  {
	      String error = "Unexpected establishment error during shutdown phase.";
		throw new SessionException( error, e );
	  }

        super.stop();
        m_started = false;
    }

    //=======================================================================
    // Disposable
    //=======================================================================

   /**
    * Disposal of the manager and release of associated resources.
    */
    public void dispose()
    {
        if( m_disposed ) return;
        m_disposed = true;

        try
        {
            m_desktop.dispose();
            m_workspace.dispose();
            m_task.dispose();
            m_user.dispose();
	  }
	  catch( Throwable e )
	  {
	      String warning = "Unexpected error during disposal phase.";
		if( getLogger().isWarnEnabled() ) getLogger().warn( warning, e );
	  }

        super.dispose();
    }

    //=======================================================================
    // SessionManager
    //=======================================================================
    
   /**
    * Retuns the name to be assigned to the POA on creation.  This is an 
    * abstract method that must be overriden by derived types.
    * @return String the POA name
    */
    protected String getPoaName()
    {
        return "SESSION";
    }

   /**
    * Returns a servant implmentation that will be managed by the servant manager.
    * This abstract method must be overriden by derived types.
    * @return Servant a managable servant
    */
    protected Servant createServant( Context context, Configuration config, ServiceManager parent ) 
    throws Exception
    {
         getLogger().debug("servant creation");
         FinderDelegate delegate = new FinderDelegate();
         Servant servant = new FinderPOATie( delegate );
         DefaultServiceManager manager = new DefaultServiceManager( parent );
         manager.put( UserService.USER_SERVICE_KEY, m_user );
         manager.put( WorkspaceService.WORKSPACE_SERVICE_KEY, m_workspace );
         manager.put( DesktopService.DESKTOP_SERVICE_KEY, m_desktop );
         manager.put( TaskService.TASK_SERVICE_KEY, m_task );
         manager.makeReadOnly();
         LifecycleHelper.pipeline( 
           delegate, getLogger().getChildLogger( "finder" ), context, config, manager );
         return servant;
    }

    //=======================================================================
    // SessionService
    //=======================================================================

    public Finder getFinder()
    {
        return m_finder;
    }
}
