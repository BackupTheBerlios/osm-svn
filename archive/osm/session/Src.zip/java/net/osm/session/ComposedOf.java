// Sun Dec 17 16:53:23 CET 2000

package net.osm.session;

import java.io.Serializable;

import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.StreamableValue;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.ValueFactory;
import org.omg.Session.AbstractResource;


public class ComposedOf extends org.omg.Session.ComposedOf
implements ValueFactory
{
    
    //================================================
    // constructor
    //================================================
    
   /**
    * Default constructor for stream internalization.
    */
    public ComposedOf () 
    {
    }

   /**
    * Creation of a new <code>ComposedOf</code> link based on a supplied AbstractResource.
    */
    public ComposedOf( AbstractResource resource ) 
    {
	  super.resource_state = resource;
    }

    //========================================================================
    // Link
    //========================================================================

   /**
    * The resource operation returns the <code>AbstractResource</code> that this 
    * composing resource is referencing.
    * @return  AbstractResource the resource composed by the resource holding this link
    */
    public AbstractResource resource()
    {
	  return super.resource_state;
    }


    //================================================
    // ValueFactory
    //================================================
    
    public Serializable read_value(org.omg.CORBA_2_3.portable.InputStream is) {
        return is.read_value( new ComposedOf() );
    }


}
