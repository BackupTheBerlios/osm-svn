// Sun Dec 17 16:53:23 CET 2000

package net.osm.session;

import java.io.Serializable;
import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.StreamableValue;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.ValueFactory;
import org.omg.Session.AbstractResource ;
import org.omg.Session.Task;

public class ProducedBy extends org.omg.Session.ProducedBy
implements ValueFactory 
{
    
    //=============================================================
    // constructors
    //=============================================================
    
   /**
    * Default constructor for stream internalization.
    */
    public ProducedBy () 
    {
    }

   /**
    * Creation of a new Produces link based on a supplied AbstractResource and
    * default tag value.
    */

    public ProducedBy( Task resource ) 
    {
	  super.resource_state = resource;
    }


   /**
    * Creation of a new Produces link based on a supplied AbstractResource and
    * tag value.
    */
    public ProducedBy( Task resource, String tag ) 
    {
	  super.resource_state = resource;
	  super.tag = tag;
    }

    //=============================================================
    // Tagged
    //=============================================================

   /**
    * The tag method returns the string value the defines the role of a resource
    * within the scope of a usage relationship.
    * @return  String tagged usage role
    */
    public String tag()
    {
        return this.tag;
    }

    //=============================================================
    // Link
    //=============================================================

   /**
    * The resource operation returns the <code>AbstractResource</code> that 
    * is produced by the <code>Task</code> holding this Link instance.
    * @return  AbstractResource produced by the Task.
    */
    public AbstractResource resource()
    {
	  return this.resource_state;
    }

    //=============================================================
    // ValueFactory
    //=============================================================
    
    public Serializable read_value(org.omg.CORBA_2_3.portable.InputStream is) 
    {
        return is.read_value( new ProducedBy() );
    }

}
