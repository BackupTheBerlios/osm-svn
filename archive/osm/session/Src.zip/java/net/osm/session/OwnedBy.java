// Sun Dec 17 16:53:23 CET 2000

package net.osm.session;

import java.io.Serializable;

import org.omg.CORBA.TypeCode;
import org.omg.CORBA.portable.StreamableValue;
import org.omg.CORBA.portable.InputStream;
import org.omg.CORBA.portable.OutputStream;
import org.omg.CORBA.portable.ValueFactory;
import org.omg.Session.AbstractResource;
import org.omg.Session.User;

public class OwnedBy extends org.omg.Session.OwnedBy
implements ValueFactory
{
            
    //==========================================
    // constructor
    //==========================================

   /**
    * Default constructor for stream internalization.
    */
    public OwnedBy () 
    {
    }

   /**
    * Creation of a new OwnedBy link based on a supplied User.
    */
    public OwnedBy( User resource ) 
    {
	  super.resource_state = resource;
    }

    //==========================================
    // OwnedBy
    //==========================================

   /**
    * The resource operation returns the <code>AbstractResource</code> that 
    * can be narrowed to a <code>User</code> that is the owner of the 
    * <code>Task</code> holding this link.
    * @return  AbstractResource representing the owner of the Task.
    */
    public AbstractResource resource()
    {
	  return this.resource_state;
    }

    //==========================================
    // ValueFactory
    //==========================================

   /**
    * OwnedBy factory.
    */
    public Serializable read_value(org.omg.CORBA_2_3.portable.InputStream is) {
        return is.read_value( new OwnedBy() );
    }

}
